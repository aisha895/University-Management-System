package department;

class Administrator extends Academics{}